class PermissionsMissing(Exception):
    pass
class NotEnoughArugments(Exception):
    pass
class MissingData(Exception):
    pass
