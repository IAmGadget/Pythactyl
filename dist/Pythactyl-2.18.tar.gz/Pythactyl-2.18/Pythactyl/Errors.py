class UserExists(Exception):
    pass
